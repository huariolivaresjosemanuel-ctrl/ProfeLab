# PROFELAB — ENTREGA DE ESPECIFICACIÓN Y PROMPT COMPLETO PARA CODEX

**Paquete:** ProfeLab V1.1 — SDD funcional, UI/UX aprobada como referencia, prompt maestro de implementación, arquitectura, esquema de datos, **134 pruebas** y 5 capturas aportadas por el usuario. **Actualizado:** contrato obligatorio de features independientes, catálogo ampliable y permisos por acción para Android.

**Estado:** DOCUMENTACIÓN, NO APP IMPLEMENTADA. No contiene APK ni código fuente funcional de ProfeLab. No se ha creado proyecto GitHub. Las capturas NO prueban que un flujo exista.

## Cómo se usa con Codex

1. Adjuntar este ZIP completo a Codex (si el entorno no puede leer ZIP, extraer los archivos y adjuntar la carpeta de documentos y capturas).
2. Copiar y pegar el archivo `03_CODEX/PROMPT_MAESTRO_CODEX_PROFELAB_V1.md` como **primer mensaje de desarrollo**; está listo para enviar.
3. Codex debe leer `02_DOCUMENTACION/` y `04_QA/` antes de implementar. Las imágenes de `01_REFERENCIAS_UI/` son referencia visual obligatoria.
4. Codex debe trabajar en **proyecto nuevo**, sin cambiar Control Personal DNI ni ScanPro. GitHub **SOLO LECTURA**. Nada de pushes/PRs; código se entrega en ZIP por hitos y el usuario sube manualmente y compila en GitHub Actions.
5. Orden de trabajo H0-H7 del prompt. H1 ya debe producir código real, no solo análisis. Cada hito lleva QA con pruebas ejecutadas y pendientes honestos.
6. La compatibilidad real de OCR offline, rendimiento de tablets, captura física y voz se confirma en dispositivo; no aceptar como PASS sin prueba.

## Contenido

```
01_REFERENCIAS_UI/
  01_INICIO.png
  02_TALLER.png
  03_SESIONES.png
  04_CUADERNO.png
  05_BIBLIOTECA.png
02_DOCUMENTACION/
  SDD_PROFELAB_V1.md
  UI_UX_PROFELAB_REFERENCIAS.md
  MODELO_DATOS_PROFELAB_V1.md
  ARQUITECTURA_Y_DECISIONES.md
  CONTRATOS_MODULOS_PERMISOS_Y_CONTENIDO.md
03_CODEX/
  PROMPT_MAESTRO_CODEX_PROFELAB_V1.md
04_QA/
  MATRIZ_QA_PROFELAB_V1.csv
  INSTRUCCIONES_QA.md
05_DATOS_EJEMPLO/
  fixtures_profelab.json
06_FUENTES/
  FUENTES_Y_LICENCIAS.md
README_PRIMERO.md
SHA256SUMS.txt
```

## Decisiones ya tomadas

- Marca visual de las cinco pantallas: **ProfeLab** (provisional hasta validación comercial).
- Barra inferior: **Inicio · Taller · Sesiones · Cuaderno · Biblioteca**.
- Estética: crema, verde bosque, tarjetas pastel, editorial/educativa adulta, móvil + tablet.
- Módulos nucleares: planificación de sesiones, material didáctico + inventario y recomendaciones, cuaderno + prácticas + notas + portafolio, biblioteca MINEDU/PDF y lector local, escáner OCR revisado, pendientes, perfil y backups.
- OCR 100% offline desde instalación limpia; diseño de revisión obligatorio; usar modelo **bundled**.
- STT offline solo si se demuestra disponibilidad y soporte; la grabación local funciona independientemente.
- PDFs oficiales solo con licencia comprobada para distribución; importar archivos propios es funcionalidad base.

## Dudas que Codex debe resolver técnicamente (sin pedir que el usuario repita decisiones de producto)

- API min/target y versiones compatibles a fecha de implementación.
- Implementación/QA de recorte de imágenes y PdfRenderer.
- Condiciones para incorporar ScanPro si después se obtiene permiso; por ahora NO copiar.
- Licencias de dependencias y derechos de plantillas.
- Rendimiento real en Android y tableta.

## QA

`04_QA/MATRIZ_QA_PROFELAB_V1.csv` contiene 134 casos todos en `NO_EJECUTADO`. Se actualizan solo después de ejecución demostrable.

## Integridad

`SHA256SUMS.txt` permite comprobar los documentos y capturas incluidos; el ZIP es una entrega de referencia, sin modificaciones a repositorios remotos.

## Nuevas condiciones obligatorias para Codex

- **Código modular feature-first:** una APK Android, secciones independientes con repositorios, modelos, UI y QA de forma aislada; cualquier cambio debe superar regresión cruzada.
- **Crecimiento por packs/importación:** añadir PDFs MINEDU autorizados, ideas, materiales, plantillas y categorías después, sin reemplazar app ni perder bases de usuario; importación validada, previsualización, migración y control de versiones.
- **Permisos solo al pulsar funciones:** cámara al escanear, micrófono al grabar, notificaciones al activarlas; selector de documentos/imágenes sin pedir acceso total a almacenamiento. **Linterna via CameraX**: detectar flash, conmutar ON/OFF, apagar al salir; sin permiso “flash” separado.
- **Requisito verificable:** QA extra para denegación/revocación y ausencia de hardware, actualización de contenidos, migraciones y aislamiento de módulos. Ver `02_DOCUMENTACION/CONTRATOS_MODULOS_PERMISOS_Y_CONTENIDO.md`.


## Fuentes MINEDU y ScanPro — actualización 29/10/2026

Se agregaron `06_FUENTES/CATALOGO_MINEDU_VERIFICADO.json`, `06_FUENTES/MINEDU_BIBLIOTECA_E_INTEGRACION.md`, `02_DOCUMENTACION/ANALISIS_SCANPRO_OCR_Y_REUTILIZACION.md`, `07_SCRIPTS/descargar_minedu.py` y los dos `08_CONTENIDOS_SEMILLA/PACK_*.json`. El catálogo ya tiene seis fuentes oficiales identificadas, con URLs y derechos indicados. No se han podido recuperar PDFs binarios por bloqueo de acceso web; **no figuran dentro del ZIP**. Codex podrá descargar los permitidos en un entorno con red sin buscar documentos de nuevo y asociarlos a la biblioteca; la publicación de PDF dentro de APK exige revisión de derechos. El material didáctico original de prueba sí viene incluido (12 ideas). Total QA ahora: **134** casos, todos NO_EJECUTADO.
